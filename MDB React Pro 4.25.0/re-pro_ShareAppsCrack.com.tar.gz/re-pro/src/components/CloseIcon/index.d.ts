export { default } from './CloseIcon';
export * from './CloseIcon';