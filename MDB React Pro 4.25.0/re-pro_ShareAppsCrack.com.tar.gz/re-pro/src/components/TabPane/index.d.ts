export { default } from './TabPane';
export * from './TabPane';