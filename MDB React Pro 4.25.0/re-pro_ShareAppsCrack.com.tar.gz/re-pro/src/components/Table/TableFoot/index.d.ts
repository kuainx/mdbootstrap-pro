export { default } from './TableFoot';
export * from './TableFoot';