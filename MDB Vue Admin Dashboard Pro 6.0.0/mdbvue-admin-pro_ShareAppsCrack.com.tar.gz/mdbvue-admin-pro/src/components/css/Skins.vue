<template>
  <mdb-container fluid>
    <h2 class="mt-lg-5 mb-5 font-weight-bold"><strong>Skins</strong></h2>

    <!--Grid row-->
    <div class="row text-center">
      <!--Grid column-->
      <div class="col-lg-4 mb-4 col-md-12">
        <img
          src="https://mdbootstrap.com/img/screens/skins/white.jpg"
          alt="Basic MDB template with a white skin."
          class="img-fluid z-depth-1"
        />
        <a
          href="https://mdbootstrap.com/previews/docs/latest/html/skins/white-skin.html"
          target="_blank"
          class="btn btn-primary my-4"
          >Live preview <i class="fas fa-eye ml-2"></i
        ></a>
      </div>
      <!--Grid column-->

      <!--Grid column-->
      <div class="col-lg-4 mb-4 col-md-6">
        <img
          src="https://mdbootstrap.com/img/screens/skins/black.jpg"
          alt="Basic MDB template with a white skin."
          class="img-fluid z-depth-1"
        />
        <a
          href="https://mdbootstrap.com/previews/docs/latest/html/skins/black-skin.html"
          target="_blank"
          class="btn btn-primary my-4"
          >Live preview <i class="fas fa-eye ml-2"></i
        ></a>
      </div>
      <!--Grid column-->

      <!--Grid column-->
      <div class="col-lg-4 mb-4 col-md-6">
        <img
          src="https://mdbootstrap.com/img/screens/skins/cyan.jpg"
          alt="Basic MDB template with a white skin."
          class="img-fluid z-depth-1"
        />
        <a
          href="https://mdbootstrap.com/previews/docs/latest/html/skins/cyan-skin.html"
          target="_blank"
          class="btn btn-primary my-4"
          >Live preview <i class="fas fa-eye ml-2"></i
        ></a>
      </div>
      <!--Grid column-->
    </div>
    <!--Grid row-->

    <!--Grid row-->
    <div class="row text-center">
      <!--Grid column-->
      <div class="col-lg-4 mb-4 col-md-12">
        <img
          src="https://mdbootstrap.com/img/screens/skins/mdb.jpg"
          alt="Basic MDB template with a white skin."
          class="img-fluid z-depth-1"
        />
        <a
          href="https://mdbootstrap.com/previews/docs/latest/html/skins/mdb-skin.html"
          target="_blank"
          class="btn btn-primary my-4"
          >Live preview <i class="fas fa-eye ml-2"></i
        ></a>
      </div>
      <!--Grid column-->

      <!--Grid column-->
      <div class="col-lg-4 mb-4 col-md-6">
        <img
          src="https://mdbootstrap.com/img/screens/skins/deep-purple.jpg"
          alt="Basic MDB template with a white skin."
          class="img-fluid z-depth-1"
        />
        <a
          href="https://mdbootstrap.com/previews/docs/latest/html/skins/deep-purple-skin.html"
          target="_blank"
          class="btn btn-primary my-4"
          >Live preview <i class="fas fa-eye ml-2"></i
        ></a>
      </div>
      <!--Grid column-->

      <!--Grid column-->
      <div class="col-lg-4 mb-4 col-md-6">
        <img
          src="https://mdbootstrap.com/img/screens/skins/navy-blue.jpg"
          alt="Basic MDB template with a white skin."
          class="img-fluid z-depth-1"
        />
        <a
          href="https://mdbootstrap.com/previews/docs/latest/html/skins/navy-blue-skin.html"
          target="_blank"
          class="btn btn-primary my-4"
          >Live preview <i class="fas fa-eye ml-2"></i
        ></a>
      </div>
      <!--Grid column-->
    </div>
    <!--Grid row-->

    <!--Grid row-->
    <div class="row text-center">
      <!--Grid column-->
      <div class="col-lg-4 mb-4 col-md-12">
        <img
          src="https://mdbootstrap.com/img/screens/skins/pink.jpg"
          alt="Basic MDB template with a white skin."
          class="img-fluid z-depth-1"
        />
        <a
          href="https://mdbootstrap.com/previews/docs/latest/html/skins/pink-skin.html"
          target="_blank"
          class="btn btn-primary my-4"
          >Live preview <i class="fas fa-eye ml-2"></i
        ></a>
      </div>
      <!--Grid column-->

      <!--Grid column-->
      <div class="col-lg-4 mb-4 col-md-6">
        <img
          src="https://mdbootstrap.com/img/screens/skins/indigo.jpg"
          alt="Basic MDB template with a white skin."
          class="img-fluid z-depth-1"
        />
        <a
          href="https://mdbootstrap.com/previews/docs/latest/html/skins/indigo-skin.html"
          target="_blank"
          class="btn btn-primary my-4"
          >Live preview <i class="fas fa-eye ml-2"></i
        ></a>
      </div>
      <!--Grid column-->

      <!--Grid column-->
      <div class="col-lg-4 mb-4 col-md-6">
        <img
          src="https://mdbootstrap.com/img/screens/skins/light-blue.jpg"
          alt="Basic MDB template with a white skin."
          class="img-fluid z-depth-1"
        />
        <a
          href="https://mdbootstrap.com/previews/docs/latest/html/skins/light-blue-skin.html"
          target="_blank"
          class="btn btn-primary my-4"
          >Live preview <i class="fas fa-eye ml-2"></i
        ></a>
      </div>
      <!--Grid column-->
    </div>
    <!--Grid row-->

    <!--Grid row-->
    <div class="row text-center">
      <!--Grid column-->
      <div class="col-lg-4 mb-4 col-md-12">
        <img
          src="https://mdbootstrap.com/img/screens/skins/grey.jpg"
          alt="Basic MDB template with a white skin."
          class="img-fluid z-depth-1"
        />
        <a
          href="https://mdbootstrap.com/previews/docs/latest/html/skins/grey-skin.html"
          target="_blank"
          class="btn btn-primary my-4"
          >Live preview <i class="fas fa-eye ml-2"></i
        ></a>
      </div>
      <!--Grid column-->

      <!--Grid column-->
      <div class="col-lg-4 col-md-6"></div>
      <!--Grid column-->

      <!--Grid column-->
      <div class="col-lg-4 col-md-6"></div>
      <!--Grid column-->
    </div>
    <!--Grid row-->

    <!--Section: Docs link-->
    <section>
      <!--Panel-->
      <div class="card text-center mb-5">
        <h3 class="card-header primary-color white-text">Full documentation</h3>
        <div class="card-body">
          <p class="card-text">
            Read the full documentation for these components.
          </p>
          <a
            href="https://mdbootstrap.com/docs/vue/css/skins/"
            target="_blank"
            class="btn btn-primary"
            >Learn more</a
          >
        </div>
      </div>
      <!--/.Panel-->
    </section>
    <!--Section: Docs link-->
  </mdb-container>
</template>

<script>
import { mdbContainer } from "mdbvue";

export default {
  name: "Skins",
  components: {
    mdbContainer,
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped></style>
