<template>
  <mdb-container fluid>
    <!--Section: Intro-->
    <section id="introduction">
      <!--Title-->
      <h2 class="mt-lg-5 font-weight-bold"><strong>Icons</strong></h2>

      <!--Description-->
      <p>
        MDB Admin Dashboard uses a powerful set of icons called Font Awesome.
      </p>
      <p class="description">
        Font Awesome gives you scalable vector icons that can instantly be
        customized — size, color, drop shadow, and anything that can be done
        with the power of CSS.
      </p>

      <!--Section: Live preview-->
      <section class="mt-5">
        <div class="row">
          <div class="col-md-4 col-sm-6 mb-4">
            <h4>
              <i class="fas fa-flag blue-text pr-2" aria-hidden="true"></i> One
              Font, 628 Icons
            </h4>
            In a single collection, Font Awesome is a pictographic language of
            web-related actions.
          </div>
          <div class="col-md-4 col-sm-6 mb-4">
            <h4>
              <i class="fas fa-ban indigo-text pr-2" aria-hidden="true"></i> No
              JavaScript Required
            </h4>
            Fewer compatibility concerns because Font Awesome doesn't require
            JavaScript.
          </div>
          <div class="col-md-4 col-sm-6 mb-4">
            <h4>
              <i
                class="fas fa-arrows-alt teal-text pr-2"
                aria-hidden="true"
              ></i>
              Infinite Scalability
            </h4>
            Scalable vector graphics means every icon looks awesome at any size.
          </div>
        </div>
        <div class="row">
          <div class="col-md-4 col-sm-6 mb-4">
            <h4>
              <i
                class="fas fa-microphone green-text pr-2"
                aria-hidden="true"
              ></i>
              Free, as in Speech
            </h4>
            Font Awesome is completely free for commercial use.
          </div>
          <div class="col-md-4 col-sm-6 mb-4">
            <h4>
              <i
                class="fas fa-pencil-alt deep-purple-text pr-2"
                aria-hidden="true"
              ></i>
              CSS Control
            </h4>
            Easily style icon color, size, shadow, and anything that's possible
            with CSS.
          </div>
          <div class="col-md-4 col-sm-6 mb-4">
            <h4>
              <i class="fas fa-eye cyan-text pr-2" aria-hidden="true"></i>
              Perfect on Retina Displays
            </h4>
            Font Awesome icons are vectors, which mean they're gorgeous on
            high-resolution displays.
          </div>
        </div>
        <div class="row">
          <div class="col-md-4 col-sm-6 mb-4">
            <h4>
              <i
                class="fas fa-wheelchair blue-text pr-2"
                aria-hidden="true"
              ></i>
              Accessibility-minded
            </h4>
            Font Awesome <i class="fas fa-heart" aria-hidden="true"></i
            ><span class="sr-only">loves</span> screen readers and helps make
            your icons accessible on the web.
          </div>
        </div>
      </section>
      <!--Section: Live preview-->
    </section>
    <!--/Section: Intro-->

    <hr class="my-5" />

    <!--Section: Examples-->
    <section>
      <h4 class="mb-5 pb-4 font-weight-bold dark-grey-text">
        <strong>Examples</strong>
      </h4>

      <!--Grid row-->
      <div class="row text-center mb-5">
        <!--Grid column-->
        <div class="col-md-4 mb-4">
          <i class="fas fa-3x mb-3 fa-chart-area red-text"></i>
          <h5 class="font-weight-bold">Analytics</h5>
          <p class="grey-text">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit.
            Reprehenderit maiores nam, aperiam minima assumenda deleniti hic.
          </p>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-md-4 mb-4">
          <i class="fas fa-3x mb-3 fa-book cyan-text"></i>
          <h5 class="font-weight-bold">Tutorials</h5>
          <p class="grey-text">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit.
            Reprehenderit maiores nam, aperiam minima assumenda deleniti hic.
          </p>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-md-4 mb-4">
          <i class="fas fa-3x mb-3 fa-coffee orange-text"></i>
          <h5 class="font-weight-bold">Relax</h5>
          <p class="grey-text">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit.
            Reprehenderit maiores nam, aperiam minima assumenda deleniti hic.
          </p>
        </div>
        <!--Grid column-->
      </div>
      <!--Grid row-->

      <!--Grid row-->
      <div class="row mb-5">
        <!--Grid column-->
        <div class="col-md-4 mb-4">
          <div class="col-1 col-md-2 float-left">
            <i class="fas fa-2x fa-bullhorn blue-text"></i>
          </div>
          <div class="col-10 col-md-9 col-lg-10 float-right">
            <h4 class="font-weight-bold">Marketing</h4>
            <p class="grey-text">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit.
              Reprehenderit maiores nam, aperiam minima assumenda.
            </p>
            <a class="btn btn-primary btn-sm ml-0">Learn more</a>
          </div>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-md-4 mb-4">
          <div class="col-1 col-md-2 float-left">
            <i class="fas fa-2x fa-cogs pink-text"></i>
          </div>
          <div class="col-10 col-md-9 col-lg-10 float-right">
            <h4 class="font-weight-bold">Customization</h4>
            <p class="grey-text">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit.
              Reprehenderit maiores nam, aperiam minima assumenda.
            </p>
            <a class="btn btn-pink btn-sm ml-0">Learn more</a>
          </div>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-md-4 mb-4">
          <div class="col-1 col-md-2 float-left">
            <i class="fas fa-2x fa-tachometer-alt deep-orange-text"></i>
          </div>
          <div class="col-10 col-md-9 col-lg-10 float-right">
            <h4 class="font-weight-bold">Support</h4>
            <p class="grey-text">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit.
              Reprehenderit maiores nam, aperiam minima assumenda.
            </p>
            <a class="btn btn-secondary btn-sm ml-0">Learn more</a>
          </div>
        </div>
        <!--Grid column-->
      </div>
      <!--Grid row-->

      <!--Grid row-->
      <div class="row mb-5 pb-5">
        <!--Grid column-->
        <div class="col-lg-3 col-md-6 mb-4">
          <div class="card white text-center z-depth-2">
            <div class="card-body my-4">
              <i class="fas fa-3x mb-4 fa-heart red-text"></i>
              <h4 class="font-weight-bold">Passion</h4>
            </div>
          </div>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-3 col-md-6 mb-4">
          <div class="card white text-center z-depth-2">
            <div class="card-body my-4">
              <i class="fas fa-3x mb-4 fa-book cyan-text"></i>
              <h4 class="font-weight-bold">Education</h4>
            </div>
          </div>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-3 col-md-6 mb-4">
          <div class="card white text-center z-depth-2">
            <div class="card-body my-4">
              <i class="fas fa-3x mb-4 fa-plane green-text"></i>
              <h4 class="font-weight-bold">Travel</h4>
            </div>
          </div>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-3 col-md-6 mb-4">
          <div class="card white text-center z-depth-2">
            <div class="card-body my-4">
              <i class="fas fa-3x mb-4 fa-laptop amber-text"></i>
              <h4 class="font-weight-bold">Work</h4>
            </div>
          </div>
        </div>
        <!--Grid column-->
      </div>
      <!--Grid row-->

      <!--Grid row-->
      <div class="row">
        <!--Grid column-->
        <div class="col-lg-3 col-md-6 mb-4">
          <div class="card transparent text-center z-depth-2">
            <div class="card-body my-4">
              <i class="fas fa-3x mb-4 fa-camera-retro indigo-text"></i>
              <h5 class="font-weight-bold indigo-text">
                <strong>PHOTOGRAPHY</strong>
              </h5>
            </div>
          </div>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-3 col-md-6 mb-4">
          <div class="card transparent text-center z-depth-2">
            <div class="card-body my-4">
              <i class="fas fa-3x mb-4 fa-pencil-alt teal-text"></i>
              <h5 class="font-weight-bold teal-text">
                <strong>DESIGN</strong>
              </h5>
            </div>
          </div>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-3 col-md-6 mb-4">
          <div class="card transparent text-center z-depth-2">
            <div class="card-body my-4">
              <i class="fas fa-3x mb-4 fa-desktop deep-purple-text"></i>
              <h5 class="font-weight-bold deep-purple-text">
                <strong>MARKETING</strong>
              </h5>
            </div>
          </div>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-3 col-md-6 mb-4">
          <div class="card transparent text-center z-depth-2">
            <div class="card-body my-4">
              <i class="fas fa-3x mb-4 fa-code blue-text"></i>
              <h5 class="font-weight-bold blue-text">
                <strong>DEVELOPMENT</strong>
              </h5>
            </div>
          </div>
        </div>
        <!--Grid column-->
      </div>
      <!--Grid row-->
    </section>
    <!--Section: Examples-->

    <!--Section: Docs link-->
    <section>
      <!--Panel-->
      <div class="card text-center">
        <h3 class="card-header primary-color white-text">Full documentation</h3>
        <div class="card-body">
          <p class="card-text">
            Read the full documentation for these components.
          </p>
          <a
            href="https://mdbootstrap.com/docs/vue/content/icons-list/"
            target="_blank"
            class="btn btn-primary"
            >Learn more</a
          >
        </div>
      </div>
      <!--/.Panel-->
    </section>
    <!--Section: Docs link-->
  </mdb-container>
</template>

<script>
import { mdbContainer } from "mdbvue";

export default {
  name: "Icons",
  components: {
    mdbContainer
  },
  data() {
    return {};
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped></style>
