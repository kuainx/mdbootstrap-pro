<template>
  <mdb-container fluid>
    <!--Section: Examples-->
    <section>
      <h2 class="mt-lg-5 mb-5 font-weight-bold"><strong>Shadows</strong></h2>

      <div class="row">
        <div class="col-md-4 mb-4">
          <div class="shadow-box-example z-depth-1 flex-center">
            <p class="white-text">.z-depth-1</p>
          </div>
        </div>

        <div class="col-md-4 mb-4">
          <div class="shadow-box-example z-depth-1-half flex-center">
            <p class="white-text">.z-depth-1-half</p>
          </div>
        </div>

        <div class="col-md-4 mb-4">
          <div class="shadow-box-example z-depth-2 flex-center">
            <p class="white-text">.z-depth-2</p>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 mb-4">
          <div class="shadow-box-example z-depth-3 flex-center">
            <p class="white-text">.z-depth-3</p>
          </div>
        </div>

        <div class="col-md-4 mb-4">
          <div class="shadow-box-example z-depth-4 flex-center">
            <p class="white-text">.z-depth-4</p>
          </div>
        </div>

        <div class="col-md-4 mb-4">
          <div class="shadow-box-example z-depth-5 flex-center">
            <p class="white-text">.z-depth-5</p>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 mb-4">
          <div class="shadow-box-example hoverable flex-center">
            <p class="white-text">hover me!</p>
          </div>
        </div>
      </div>
    </section>
    <!--Section: Examples-->

    <!--Section: Docs link-->
    <section>
      <!--Panel-->
      <div class="card text-center my-5">
        <h3 class="card-header primary-color white-text">Full documentation</h3>
        <div class="card-body">
          <p class="card-text">
            Read the full documentation for these components.
          </p>
          <a
            href="https://mdbootstrap.com/shadows/"
            target="_blank"
            class="btn btn-primary"
            >Learn more</a
          >
        </div>
      </div>
      <!--/.Panel-->
    </section>
    <!--Section: Docs link-->
  </mdb-container>
</template>

<script>
import { mdbContainer } from "mdbvue";

export default {
  name: "Shadows",
  components: {
    mdbContainer
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.shadow-box-example {
  height: 120px;
  width: 100%;
  background-color: #64b5f6;
}
</style>
