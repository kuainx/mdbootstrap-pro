<template>
  <mdb-container fluid>
    <h2 class="mt-5 font-weight-bold"><strong>Grid system</strong></h2>

    <!--Section: Five grid tiers-->
    <section class="mt-5">
      <h4 class="my-5 dark-grey-text font-weight-bold">
        <strong>Five grid tiers</strong>
      </h4>

      <mdb-row>
        <!--Grid column-->
        <mdb-col col="4">
          <div class="card white text-center z-depth-2">
            <div class="card-body">
              <p class="mb-0">.col-4</p>
            </div>
          </div>
        </mdb-col>
        <!--Grid column-->

        <!--Grid column-->
        <mdb-col col="4">
          <div class="card white text-center z-depth-2">
            <div class="card-body">
              <p class="mb-0">.col-4</p>
            </div>
          </div>
        </mdb-col>
        <!--Grid column-->

        <!--Grid column-->
        <mdb-col col="4">
          <div class="card white text-center z-depth-2">
            <div class="card-body">
              <p class="mb-0">.col-4</p>
            </div>
          </div>
        </mdb-col>
        <!--Grid column-->
      </mdb-row>

      <mdb-row class="mt-4">
        <!--Grid column-->
        <mdb-col sm="4">
          <div class="card white text-center z-depth-2">
            <div class="card-body">
              <p class="mb-0">.col-sm-4</p>
            </div>
          </div>
        </mdb-col>
        <!--Grid column-->

        <!--Grid column-->
        <mdb-col sm="4">
          <div class="card white text-center z-depth-2">
            <div class="card-body">
              <p class="mb-0">.col-sm-4</p>
            </div>
          </div>
        </mdb-col>
        <!--Grid column-->

        <!--Grid column-->
        <mdb-col sm="4">
          <div class="card white text-center z-depth-2">
            <div class="card-body">
              <p class="mb-0">.col-sm-4</p>
            </div>
          </div>
        </mdb-col>
        <!--Grid column-->
      </mdb-row>

      <mdb-row class="mt-4">
        <!--Grid column-->
        <mdb-col md="4">
          <div class="card white text-center z-depth-2">
            <div class="card-body">
              <p class="mb-0">.col-md-4</p>
            </div>
          </div>
        </mdb-col>
        <!--Grid column-->

        <!--Grid column-->
        <mdb-col md="4">
          <div class="card white text-center z-depth-2">
            <div class="card-body">
              <p class="mb-0">.col-md-4</p>
            </div>
          </div>
        </mdb-col>
        <!--Grid column-->

        <!--Grid column-->
        <mdb-col md="4">
          <div class="card white text-center z-depth-2">
            <div class="card-body">
              <p class="mb-0">.col-md-4</p>
            </div>
          </div>
        </mdb-col>
        <!--Grid column-->
      </mdb-row>

      <mdb-row class="mt-4">
        <!--Grid column-->
        <mdb-col lg="4">
          <div class="card white text-center z-depth-2">
            <div class="card-body">
              <p class="mb-0">.col-lg-4</p>
            </div>
          </div>
        </mdb-col>
        <!--Grid column-->

        <!--Grid column-->
        <mdb-col lg="4">
          <div class="card white text-center z-depth-2">
            <div class="card-body">
              <p class="mb-0">.col-lg-4</p>
            </div>
          </div>
        </mdb-col>
        <!--Grid column-->

        <!--Grid column-->
        <mdb-col lg="4">
          <div class="card white text-center z-depth-2">
            <div class="card-body">
              <p class="mb-0">.col-lg-4</p>
            </div>
          </div>
        </mdb-col>
        <!--Grid column-->
      </mdb-row>

      <mdb-row class="mt-4">
        <!--Grid column-->
        <mdb-col xl="4">
          <div class="card white text-center z-depth-2">
            <div class="card-body">
              <p class="mb-0">.col-xl-4</p>
            </div>
          </div>
        </mdb-col>
        <!--Grid column-->

        <!--Grid column-->
        <mdb-col xl="4">
          <div class="card white text-center z-depth-2">
            <div class="card-body">
              <p class="mb-0">.col-xl-4</p>
            </div>
          </div>
        </mdb-col>
        <!--Grid column-->

        <!--Grid column-->
        <mdb-col xl="4">
          <div class="card white text-center z-depth-2">
            <div class="card-body">
              <p class="mb-0">.col-xl-4</p>
            </div>
          </div>
        </mdb-col>
        <!--Grid column-->
      </mdb-row>
    </section>
    <!--Section: Five grid tiers-->

    <!--Section: Three equal columns-->
    <section class="mb-5">
      <div class="container-fluid mt-5">
        <h4 class="my-5 pt-4 dark-grey-text font-weight-bold">
          <strong>Three equal columns</strong>
        </h4>

        <mdb-row class="mt-4">
          <!--Grid column-->
          <mdb-col md="4">
            <div class="card white text-center z-depth-2">
              <div class="card-body">
                <p class=" mb-0">.col-md-4</p>
              </div>
            </div>
          </mdb-col>
          <!--Grid column-->

          <!--Grid column-->
          <mdb-col md="4">
            <div class="card white text-center z-depth-2">
              <div class="card-body">
                <p class=" mb-0">.col-md-4</p>
              </div>
            </div>
          </mdb-col>
          <!--Grid column-->

          <!--Grid column-->
          <mdb-col md="4">
            <div class="card white text-center z-depth-2">
              <div class="card-body">
                <p class=" mb-0">.col-md-4</p>
              </div>
            </div>
          </mdb-col>
          <!--Grid column-->
        </mdb-row>
      </div>
    </section>
    <!--Section: Three equal columns-->

    <!--Section: Two columns-->
    <section class="mb-5">
      <div class="container-fluid mt-5">
        <h4 class="my-5 pt-4 dark-grey-text font-weight-bold">
          <strong>Two columns</strong>
        </h4>

        <mdb-row>
          <!--Grid column-->
          <mdb-col md="8">
            <div class="card white text-center z-depth-2">
              <div class="card-body">
                <p class=" mb-0">.col-md-8</p>
              </div>
            </div>
          </mdb-col>
          <!--Grid column-->

          <!--Grid column-->
          <mdb-col md="4">
            <div class="card white text-center z-depth-2">
              <div class="card-body">
                <p class=" mb-0">.col-md-4</p>
              </div>
            </div>
          </mdb-col>
          <!--Grid column-->
        </mdb-row>
      </div>
    </section>
    <!--Section: Two columns-->

    <!--Section: Mixed: mobile and desktop-->
    <section class="mb-5">
      <div class="container-fluid mt-5">
        <h4 class="my-5 pt-4 dark-grey-text font-weight-bold">
          <strong>Mixed: mobile and desktop</strong>
        </h4>

        <mdb-row>
          <!--Grid column-->
          <mdb-col col="12" md="8">
            <div class="card white text-center z-depth-2">
              <div class="card-body">
                <p class=" mb-0">.col-12 .col-md-8</p>
              </div>
            </div>
          </mdb-col>
          <!--Grid column-->

          <!--Grid column-->
          <mdb-col col="6" md="4">
            <div class="card white text-center z-depth-2">
              <div class="card-body">
                <p class=" mb-0">.col-6 .col-md-4</p>
              </div>
            </div>
          </mdb-col>
          <!--Grid column-->
        </mdb-row>

        <mdb-row class="mt-4">
          <!--Grid column-->
          <mdb-col col="6" md="4">
            <div class="card white text-center z-depth-2">
              <div class="card-body">
                <p class=" mb-0">.col-6 .col-md-4</p>
              </div>
            </div>
          </mdb-col>
          <!--Grid column-->

          <!--Grid column-->
          <mdb-col col="6" md="4">
            <div class="card white text-center z-depth-2">
              <div class="card-body">
                <p class=" mb-0">.col-6 .col-md-4</p>
              </div>
            </div>
          </mdb-col>
          <!--Grid column-->

          <!--Grid column-->
          <mdb-col col="6" md="4">
            <div class="card white text-center z-depth-2">
              <div class="card-body">
                <p class=" mb-0">.col-6 .col-md-4</p>
              </div>
            </div>
          </mdb-col>
          <!--Grid column-->
        </mdb-row>

        <mdb-row class="mt-4">
          <!--Grid column-->
          <mdb-col col="6">
            <div class="card white text-center z-depth-2">
              <div class="card-body">
                <p class=" mb-0">.col-md-6</p>
              </div>
            </div>
          </mdb-col>
          <!--Grid column-->

          <!--Grid column-->
          <mdb-col col="6">
            <div class="card white text-center z-depth-2">
              <div class="card-body">
                <p class=" mb-0">.col-6</p>
              </div>
            </div>
          </mdb-col>
          <!--Grid column-->
        </mdb-row>
      </div>
    </section>
    <!--Section: Mixed: mobile and desktop-->

    <!--Section: Mixed: mobile, tablet, and desktop-->
    <section class="mb-5">
      <div class="container-fluid mt-5">
        <h4 class="my-5 pt-4 dark-grey-text font-weight-bold">
          <strong>Mixed: mobile, tablet, and desktop</strong>
        </h4>

        <mdb-row>
          <!--Grid column-->
          <mdb-col col="12" sm="6" lg="8">
            <div class="card white text-center z-depth-2">
              <div class="card-body">
                <p class="mb-0">.col-12 .col-sm-6 .col-lg-8</p>
              </div>
            </div>
          </mdb-col>
          <!--Grid column-->

          <!--Grid column-->
          <mdb-col col="6" lg="4">
            <div class="card white text-center z-depth-2">
              <div class="card-body">
                <p class=" mb-0">.col-6 .col-lg-4</p>
              </div>
            </div>
          </mdb-col>
          <!--Grid column-->
        </mdb-row>

        <mdb-row class="mt-4">
          <!--Grid column-->
          <mdb-col col="6" sm="4">
            <div class="card white text-center z-depth-2">
              <div class="card-body">
                <p class=" mb-0">.col-6. col-sm-4</p>
              </div>
            </div>
          </mdb-col>
          <!--Grid column-->

          <!--Grid column-->
          <mdb-col col="6" sm="4">
            <div class="card white text-center z-depth-2">
              <div class="card-body">
                <p class=" mb-0">.col-6 .col-sm-4</p>
              </div>
            </div>
          </mdb-col>
          <!--Grid column-->

          <!--Grid column-->
          <mdb-col col="6" sm="4">
            <div class="card white text-center z-depth-2">
              <div class="card-body">
                <p class=" mb-0">.col-6 .col-sm-4</p>
              </div>
            </div>
          </mdb-col>
          <!--Grid column-->
        </mdb-row>
      </div>
    </section>
    <!--Section: Mixed: mobile, tablet, and desktop-->

    <!--Section: Two columns with two nested columns-->
    <section class="mb-5 pb-4">
      <div class="container-fluid mt-5">
        <h4 class="my-5 pt-4 dark-grey-text font-weight-bold">
          <strong>Two columns with two nested columns</strong>
        </h4>

        <mdb-row>
          <!--Grid column-->
          <mdb-col md="8">
            <div class="card white text-center z-depth-2">
              <div class="card-body">
                <p class="mb-4 mt-2">.col-md-8</p>

                <mdb-row>
                  <mdb-col md="6">
                    <div class="card grey lighten-2 text-center z-depth-2">
                      <div class="card-body">
                        <p class="mb-0">.col-md-6</p>
                      </div>
                    </div>
                  </mdb-col>

                  <mdb-col md="6">
                    <div class="card grey lighten-2 text-center z-depth-2">
                      <div class="card-body">
                        <p class="mb-0">.col-md-6</p>
                      </div>
                    </div>
                  </mdb-col>
                </mdb-row>
              </div>
            </div>
            <!--Grid column-->
          </mdb-col>

          <!--Grid column-->
          <mdb-col md="4">
            <div class="card white text-center z-depth-2">
              <div class="card-body">
                <p class="my-5">.col-md-4</p>
              </div>
            </div>
          </mdb-col>
        </mdb-row>
      </div>
    </section>
    <!--Section: Two columns with two nested columns-->

    <!--Section: Docs link-->
    <section>
      <!--Panel-->
      <div class="card text-center">
        <h3 class="card-header primary-color white-text">Full documentation</h3>
        <div class="card-body">
          <p class="card-text">
            Read the full documentation for these components.
          </p>
          <a
            href="https://mdbootstrap.com/grid-usage/"
            target="_blank"
            class="btn btn-primary"
            >Learn more</a
          >
        </div>
      </div>
      <!--/.Panel-->
    </section>
    <!--Section: Docs link-->
  </mdb-container>
</template>

<script>
import { mdbContainer, mdbRow, mdbCol } from "mdbvue";

export default {
  name: "Grid",
  components: {
    mdbContainer,
    mdbRow,
    mdbCol
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped></style>
