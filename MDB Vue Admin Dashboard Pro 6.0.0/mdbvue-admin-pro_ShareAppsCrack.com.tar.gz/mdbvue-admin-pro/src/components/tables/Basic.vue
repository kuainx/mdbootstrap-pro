<template>
  <mdb-container fluid>
    <!--Section: Basic examples-->
    <section>
      <mdb-card>
        <mdb-card-body>
          <!--Table-->
          <table class="table">
            <!--Table head-->
            <thead>
              <tr>
                <th>#</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Username</th>
              </tr>
            </thead>
            <!--Table head-->

            <!--Table body-->
            <tbody>
              <tr>
                <th scope="row">1</th>
                <td>Mark</td>
                <td>Otto</td>
                <td>@mdo</td>
              </tr>
              <tr>
                <th scope="row">2</th>
                <td>Jacob</td>
                <td>Thornton</td>
                <td>@fat</td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <td>Larry</td>
                <td>the Bird</td>
                <td>@twitter</td>
              </tr>
            </tbody>
            <!--Table body-->
          </table>
          <!--Table-->
        </mdb-card-body>
      </mdb-card>
    </section>
    <!--Section: Basic examples-->

    <hr class="my-5" />

    <!--Section: Head options-->
    <section>
      <mdb-card>
        <mdb-card-body>
          <!--Table-->
          <table class="table">
            <!--Table head-->
            <thead class="blue-grey lighten-4">
              <tr>
                <th>#</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Username</th>
              </tr>
            </thead>
            <!--Table head-->

            <!--Table body-->
            <tbody>
              <tr>
                <th scope="row">1</th>
                <td>Mark</td>
                <td>Otto</td>
                <td>@mdo</td>
              </tr>
              <tr>
                <th scope="row">2</th>
                <td>Jacob</td>
                <td>Thornton</td>
                <td>@fat</td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <td>Larry</td>
                <td>the Bird</td>
                <td>@twitter</td>
              </tr>
            </tbody>
            <!--Table body-->
          </table>
          <!--Table-->
        </mdb-card-body>
      </mdb-card>

      <div class="my-5"></div>

      <mdb-card>
        <mdb-card-body>
          <!--Table-->
          <table class="table">
            <!--Table head-->
            <thead class="mdb-color darken-3">
              <tr class="text-white">
                <th>#</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Username</th>
              </tr>
            </thead>
            <!--Table head-->

            <!--Table body-->
            <tbody>
              <tr>
                <th scope="row">1</th>
                <td>Mark</td>
                <td>Otto</td>
                <td>@mdo</td>
              </tr>
              <tr>
                <th scope="row">2</th>
                <td>Jacob</td>
                <td>Thornton</td>
                <td>@fat</td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <td>Larry</td>
                <td>the Bird</td>
                <td>@twitter</td>
              </tr>
            </tbody>
            <!--Table body-->
          </table>
          <!--Table-->
        </mdb-card-body>
      </mdb-card>
    </section>
    <!--Section: Head options-->

    <hr class="my-5" />

    <!--Section: Striped rows-->
    <section>
      <mdb-card>
        <mdb-card-body>
          <!--Table-->
          <table class="table table-striped">
            <!--Table head-->
            <thead>
              <tr>
                <th>#</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Username</th>
              </tr>
            </thead>
            <!--Table head-->

            <!--Table body-->
            <tbody>
              <tr>
                <th scope="row">1</th>
                <td>Mark</td>
                <td>Otto</td>
                <td>@mdo</td>
              </tr>
              <tr>
                <th scope="row">2</th>
                <td>Jacob</td>
                <td>Thornton</td>
                <td>@fat</td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <td>Larry</td>
                <td>the Bird</td>
                <td>@twitter</td>
              </tr>
              <tr>
                <th scope="row">1</th>
                <td>Mark</td>
                <td>Otto</td>
                <td>@mdo</td>
              </tr>
              <tr>
                <th scope="row">2</th>
                <td>Jacob</td>
                <td>Thornton</td>
                <td>@fat</td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <td>Larry</td>
                <td>the Bird</td>
                <td>@twitter</td>
              </tr>
            </tbody>
            <!--Table body-->
          </table>
          <!--Table-->
        </mdb-card-body>
      </mdb-card>
    </section>
    <!--Section: Striped rows-->

    <hr class="my-5" />

    <!--Section: Bordered table-->
    <section>
      <mdb-card>
        <!--Table-->
        <table class="table table-bordered mb-0">
          <!--Table head-->
          <thead>
            <tr>
              <th>#</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Username</th>
            </tr>
          </thead>
          <!--Table head-->

          <!--Table body-->
          <tbody>
            <tr>
              <th scope="row">1</th>
              <td>Mark</td>
              <td>Otto</td>
              <td>@mdo</td>
            </tr>
            <tr>
              <th scope="row">2</th>
              <td>Jacob</td>
              <td>Thornton</td>
              <td>@fat</td>
            </tr>
            <tr>
              <th scope="row">3</th>
              <td>Larry</td>
              <td>the Bird</td>
              <td>@twitter</td>
            </tr>
            <tr>
              <th scope="row">1</th>
              <td>Mark</td>
              <td>Otto</td>
              <td>@mdo</td>
            </tr>
            <tr>
              <th scope="row">2</th>
              <td>Jacob</td>
              <td>Thornton</td>
              <td>@fat</td>
            </tr>
            <tr>
              <th scope="row">3</th>
              <td>Larry</td>
              <td>the Bird</td>
              <td>@twitter</td>
            </tr>
          </tbody>
          <!--Table body-->
        </table>
        <!--Table-->
      </mdb-card>
    </section>
    <!--Section: Bordered table-->

    <hr class="my-5" />

    <!--Section: Hoverable -->
    <section>
      <mdb-card>
        <mdb-card-body>
          <!--Table-->
          <table class="table table-hover">
            <!--Table head-->
            <thead>
              <tr>
                <th>#</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Username</th>
              </tr>
            </thead>
            <!--Table head-->

            <!--Table body-->
            <tbody>
              <tr>
                <th scope="row">1</th>
                <td>Mark</td>
                <td>Otto</td>
                <td>@mdo</td>
              </tr>
              <tr>
                <th scope="row">2</th>
                <td>Jacob</td>
                <td>Thornton</td>
                <td>@fat</td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <td>Larry</td>
                <td>the Bird</td>
                <td>@twitter</td>
              </tr>
            </tbody>
            <!--Table body-->
          </table>
          <!--Table-->
        </mdb-card-body>
      </mdb-card>
    </section>
    <!--Section: Hoverable -->

    <hr class="my-5" />

    <!--Section: Responsive-->
    <section>
      <mdb-card>
        <mdb-card-body>
          <!--Table-->
          <table class="table table-responsive">
            <thead>
              <tr>
                <th>#</th>
                <th class="th-lg">Table heading</th>
                <th class="th-lg">Table heading</th>
                <th class="th-lg">Table heading</th>
                <th class="th-lg">Table heading</th>
                <th class="th-lg">Table heading</th>
                <th class="th-lg">Table heading</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row">1</th>
                <td>Table cell</td>
                <td>Table cell</td>
                <td>Table cell</td>
                <td>Table cell</td>
                <td>Table cell</td>
                <td>Table cell</td>
              </tr>
              <tr>
                <th scope="row">2</th>
                <td>Table cell</td>
                <td>Table cell</td>
                <td>Table cell</td>
                <td>Table cell</td>
                <td>Table cell</td>
                <td>Table cell</td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <td>Table cell</td>
                <td>Table cell</td>
                <td>Table cell</td>
                <td>Table cell</td>
                <td>Table cell</td>
                <td>Table cell</td>
              </tr>
            </tbody>
          </table>
          <!--Table-->
        </mdb-card-body>
      </mdb-card>
    </section>
    <!--Section: Responsive-->

    <!--Section: Docs link-->
    <section class="pb-4 pt-5">
      <!--Panel-->
      <mdb-card class="text-center">
        <mdb-card-header tag="h3" class="primary-color white-text">Full documentation</mdb-card-header>
        <mdb-card-body>
          <mdb-card-text>
            Read the full documentation for these components.
          </mdb-card-text>
          <a
            href="https://mdbootstrap.com/docs/vue/tables/basic/"
            target="_blank"
            class="btn btn-primary"
            >Learn more</a
          >
        </mdb-card-body>
      </mdb-card>
      <!--/.Panel-->
    </section>
    <!--Section: Docs link-->
  </mdb-container>
</template>

<script>
import { mdbContainer, mdbCardBody, mdbCard, mdbCardText, mdbCardHeader } from "mdbvue";

export default {
  name: "Basic",
  components: {
    mdbContainer, mdbCardBody, mdbCard, mdbCardText, mdbCardHeader
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped></style>
