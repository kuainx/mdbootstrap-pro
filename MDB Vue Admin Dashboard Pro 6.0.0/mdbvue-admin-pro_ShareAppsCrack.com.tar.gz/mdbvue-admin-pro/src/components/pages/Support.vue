<template>
  <mdb-container fluid>
    <!-- First row -->
    <div class="row pt-5 pb-3">
      <!-- First column -->
      <div class="col-md-3 mx-auto mb-4">
        <div class="card-body pt-0">
          <button
            type="button"
            class="btn btn-primary btn-lg btn-block"
            data-toggle="modal"
            data-target="#modal-support"
          >
            <i class="fas fa-plus left"></i> New Ticket
          </button>

          <div class="mt-2">
            <small>Ticket categories:</small>

            <ul class="striped list-unstyled">
              <li>
                <span class="bullet green"></span> Invoices
                <span class="badge bg-primary float-right">14</span>
              </li>
              <li>
                <span class="bullet blue"></span> Advertising
                <span class="badge bg-primary float-right">1</span>
              </li>
              <li>
                <span class="bullet red"></span> Functions
                <span class="badge bg-primary float-right">3</span>
              </li>
              <li>
                <span class="bullet yellow"></span> Website
                <span class="badge bg-primary float-right">9</span>
              </li>
              <li>
                <span class="bullet orange"></span> Clients
                <span class="badge bg-primary float-right">5</span>
              </li>
              <li>
                <span class="bullet deep-purple"></span> Technical Questions
                <span class="badge bg-primary label-pill float-right">4</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <!-- /.First column -->

      <!-- Second column -->
      <div class="col-md-8 mx-auto white z-depth-1 mb-4">
        <div class="row">
          <div class="col-sm-6 col-md-9 py-4 px-3">
            <h4 class="h4-responsive">Support Tickets (36)</h4>
          </div>
          <div class="col-sm-6 col-md-3">
            <div class="md-form">
              <input
                placeholder="Search..."
                type="text"
                id="form5"
                class="form-control"
              />
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-md-12 pb-3">
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th>
                      <fieldset class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          id="checkbox0"
                        />
                        <label class="form-check-label" for="checkbox0"></label>
                      </fieldset>
                    </th>
                    <th>Name</th>
                    <th>Title</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th scope="row">
                      <fieldset class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          id="checkbox1"
                        />
                        <label class="form-check-label" for="checkbox1"></label>
                      </fieldset>
                    </th>
                    <td>
                      <div class="avatar-placeholder green darken-3">A</div>
                      Abby Barret
                    </td>
                    <td>Can't create a modal</td>
                    <td>
                      <span class="grey-text"
                        ><small><i class="far fa-clock"></i> 5 min</small></span
                      >
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <fieldset class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          id="checkbox2"
                        />
                        <label class="form-check-label" for="checkbox2"></label>
                      </fieldset>
                    </th>
                    <td>
                      <img
                        src="http://mdbootstrap.com/wp-content/uploads/2015/10/avatar-1.jpg"
                        alt="Danny Collins"
                        class="avatar-32"
                      />
                      Danny Collins
                    </td>
                    <td>Account changes won't save</td>
                    <td>
                      <span class="grey-text"
                        ><small
                          ><i class="far fa-clock"></i> 1 hour</small
                        ></span
                      >
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <fieldset class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          id="checkbox3"
                        />
                        <label class="form-check-label" for="checkbox3"></label>
                      </fieldset>
                    </th>
                    <td>
                      <img
                        src="http://mdbootstrap.com/wp-content/uploads/2015/10/avatar-3.jpg"
                        alt="Danny Collins"
                        class="avatar-32"
                      />
                      Clara Ericson
                    </td>
                    <td>How to import my campaign from Business Manager?</td>
                    <td>
                      <span class="grey-text"
                        ><small
                          ><i class="far fa-clock"></i> 1 hour</small
                        ></span
                      >
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <fieldset class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          id="checkbox4"
                        />
                        <label class="form-check-label" for="checkbox4"></label>
                      </fieldset>
                    </th>
                    <td>
                      <div class="avatar-placeholder green darken-3">A</div>
                      Abby Barret
                    </td>
                    <td>Can't create a modal</td>
                    <td>
                      <span class="grey-text"
                        ><small><i class="far fa-clock"></i> 5 min</small></span
                      >
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <fieldset class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          id="checkbox5"
                        />
                        <label class="form-check-label" for="checkbox5"></label>
                      </fieldset>
                    </th>
                    <td>
                      <div class="avatar-placeholder yellow darken-2">D</div>
                      Danny Collins
                    </td>
                    <td>Account changes won't save</td>
                    <td>
                      <span class="grey-text"
                        ><small
                          ><i class="far fa-clock"></i> 1 hour</small
                        ></span
                      >
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <fieldset class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          id="checkbox6"
                        />
                        <label class="form-check-label" for="checkbox6"></label>
                      </fieldset>
                    </th>
                    <td>
                      <div class="avatar-placeholder red darken-2">C</div>
                      Clara Ericson
                    </td>
                    <td>How to import my campaign from Business Manager?</td>
                    <td>
                      <span class="grey-text"
                        ><small
                          ><i class="far fa-clock"></i> 1 hour</small
                        ></span
                      >
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <fieldset class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          id="checkbox7"
                        />
                        <label class="form-check-label" for="checkbox7"></label>
                      </fieldset>
                    </th>
                    <td>
                      <img
                        src="http://mdbootstrap.com/wp-content/uploads/2015/10/avatar-2.jpg"
                        alt="Danny Collins"
                        class="avatar-32"
                      />
                      Abby Barret
                    </td>
                    <td>Can't create a modal</td>
                    <td>
                      <span class="grey-text"
                        ><small><i class="far fa-clock"></i> 5 min</small></span
                      >
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <fieldset class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          id="checkbox8"
                        />
                        <label class="form-check-label" for="checkbox8"></label>
                      </fieldset>
                    </th>
                    <td>
                      <div class="avatar-placeholder yellow darken-2">D</div>
                      Danny Collins
                    </td>
                    <td>Account changes won't save</td>
                    <td>
                      <span class="grey-text"
                        ><small
                          ><i class="far fa-clock"></i> 1 hour</small
                        ></span
                      >
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <fieldset class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          id="checkbox9"
                        />
                        <label class="form-check-label" for="checkbox9"></label>
                      </fieldset>
                    </th>
                    <td>
                      <div class="avatar-placeholder red darken-2">C</div>
                      Clara Ericson
                    </td>
                    <td>How to import my campaign from Business Manager?</td>
                    <td>
                      <span class="grey-text"
                        ><small
                          ><i class="far fa-clock"></i> 1 hour</small
                        ></span
                      >
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <fieldset class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          id="checkbox10"
                        />
                        <label
                          class="form-check-label"
                          for="checkbox10"
                        ></label>
                      </fieldset>
                    </th>
                    <td>
                      <div class="avatar-placeholder green darken-3">A</div>
                      Abby Barret
                    </td>
                    <td>Can't create a modal</td>
                    <td>
                      <span class="grey-text"
                        ><small><i class="far fa-clock"></i> 5 min</small></span
                      >
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <fieldset class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          id="checkbox11"
                        />
                        <label
                          class="form-check-label"
                          for="checkbox11"
                        ></label>
                      </fieldset>
                    </th>
                    <td>
                      <img
                        src="http://mdbootstrap.com/wp-content/uploads/2015/10/avatar-1.jpg"
                        alt="Danny Collins"
                        class="avatar-32"
                      />
                      Danny Collins
                    </td>
                    <td>Account changes won't save</td>
                    <td>
                      <span class="grey-text"
                        ><small
                          ><i class="far fa-clock"></i> 1 hour</small
                        ></span
                      >
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">
                      <fieldset class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          id="checkbox12"
                        />
                        <label
                          class="form-check-label"
                          for="checkbox12"
                        ></label>
                      </fieldset>
                    </th>
                    <td>
                      <div class="avatar-placeholder red darken-2">C</div>
                      Clara Ericson
                    </td>
                    <td>How to import my campaign from Business Manager?</td>
                    <td>
                      <span class="grey-text"
                        ><small
                          ><i class="far fa-clock"></i> 1 hour</small
                        ></span
                      >
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            <mdb-dropdown dropup>
              <mdb-dropdown-toggle slot="toggle" color="primary"
                >Selected</mdb-dropdown-toggle
              >
              <mdb-dropdown-menu dropup>
                <mdb-dropdown-item>Remove</mdb-dropdown-item>
                <mdb-dropdown-item>Mark as read</mdb-dropdown-item>
                <mdb-dropdown-item>Archive</mdb-dropdown-item>
              </mdb-dropdown-menu>
            </mdb-dropdown>
          </div>
        </div>
      </div>
      <!-- /.Second column -->
    </div>
    <!-- /.First row -->
  </mdb-container>
</template>

<script>
import {
  mdbContainer,
  mdbDropdown,
  mdbDropdownToggle,
  mdbDropdownMenu,
  mdbDropdownItem
} from "mdbvue";

export default {
  name: "Support",
  components: {
    mdbContainer,
    mdbDropdown,
    mdbDropdownToggle,
    mdbDropdownMenu,
    mdbDropdownItem
  },
  data() {
    return {};
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.avatar-placeholder {
  height: 32px;
  color: rgba(255, 255, 255, 0.75);
  text-align: center;
  line-height: 32px;
  -webkit-border-radius: 50%;
  border-radius: 50%;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  cursor: default;
}
.avatar-32,
.avatar-placeholder {
  width: 32px;
  margin-right: 8px;
  display: inline-block;
}
.avatar-32 {
  -webkit-border-radius: 50%;
  border-radius: 50%;
}
.avatar-32,
.avatar-placeholder {
  width: 32px;
  margin-right: 8px;
  display: inline-block;
}
</style>
