<template>
  <mdb-container fluid>
    <!-- First row -->
    <mdb-row>
      <!-- First column -->
      <mdb-col xl="3" md="6" class="mb-4">
        <!--Card-->
        <mdb-card cascade class="cascading-admin-card">
          <!--Card Data-->
          <div class="admin-up">
            <i class="fas fa-money-bill primary-color"></i>
            <div class="data">
              <p>SALES</p>
              <h3 class="font-weight-bold dark-grey-text">4 571 $</h3>
            </div>
          </div>
          <!--/.Card Data-->

          <!--Card content-->
          <mdb-card-body cascade>
            <div class="progress mb-3">
              <div
                class="progress-bar bg-primary"
                role="progressbar"
                style="width: 25%"
                aria-valuenow="25"
                aria-valuemin="0"
                aria-valuemax="100"
              ></div>
            </div>
            <!--Text-->
            <p class="card-text">Better than last week (25%)</p>
          </mdb-card-body>
          <!--/.Card content-->
        </mdb-card>
        <!--/.Card-->
      </mdb-col>

      <!-- Second column -->
      <mdb-col xl="3" md="6" class="mb-4">
        <!--Card-->
        <mdb-card cascade class="cascading-admin-card">
          <!--Card Data-->
          <div class="admin-up">
            <i class="fas fa-chart-line warning-color"></i>
            <div class="data">
              <p>SUBSCRIPTIONS</p>
              <h3 class="font-weight-bold dark-grey-text">375</h3>
            </div>
          </div>
          <!--/.Card Data-->

          <!--Card content-->
          <mdb-card-body cascade>
            <div class="progress mb-3">
              <div
                class="progress-bar red accent-2"
                role="progressbar"
                style="width: 25%"
                aria-valuenow="25"
                aria-valuemin="0"
                aria-valuemax="100"
              ></div>
            </div>
            <!--Text-->
            <p class="card-text">Worse than last week (25%)</p>
          </mdb-card-body>
          <!--/.Card content-->
        </mdb-card>
        <!--/.Card-->
      </mdb-col>

      <!-- Third column -->
      <mdb-col xl="3" md="6" class="mb-4">
        <!--Card-->
        <mdb-card cascade class="cascading-admin-card">
          <!--Card Data-->
          <div class="admin-up">
            <i class="fas fa-chart-pie light-blue lighten-1"></i>
            <div class="data">
              <p>TRAFFIC</p>
              <h3 class="font-weight-bold dark-grey-text">21 479</h3>
            </div>
          </div>
          <!--/.Card Data-->

          <!--Card content-->
          <mdb-card-body cascade>
            <div class="progress mb-3">
              <div
                class="progress-bar red accent-2"
                role="progressbar"
                style="width: 75%"
                aria-valuenow="75"
                aria-valuemin="0"
                aria-valuemax="100"
              ></div>
            </div>
            <!--Text-->
            <p class="card-text">Worse than last week (75%)</p>
          </mdb-card-body>
          <!--/.Card content-->
        </mdb-card>
        <!--/.Card-->
      </mdb-col>

      <!-- Fourth column -->
      <mdb-col xl="3" md="6" class="mb-4">
        <!--Card-->
        <mdb-card cascade class="cascading-admin-card">
          <!--Card Data-->
          <div class="admin-up">
            <i class="fas fa-chart-bar red accent-2"></i>
            <div class="data">
              <p>ORGANIC T.</p>
              <h3 class="font-weight-bold dark-grey-text">4 567</h3>
            </div>
          </div>
          <!--/.Card Data-->

          <!--Card content-->
          <mdb-card-body cascade>
            <div class="progress mb-3">
              <div
                class="progress-bar bg-primary"
                role="progressbar"
                style="width: 25%"
                aria-valuenow="25"
                aria-valuemin="0"
                aria-valuemax="100"
              ></div>
            </div>
            <!--Text-->
            <p class="card-text">Better than last week (25%)</p>
          </mdb-card-body>
          <!--/.Card content-->
        </mdb-card>
        <!--/.Card-->
      </mdb-col>
    </mdb-row>
    <!-- /.First row -->

    <!-- Second row -->

    <mdb-row>
      <!-- First column -->

      <mdb-col lg="6" md="12">
        <!--Panel-->
        <mdb-card class="mb-4">
          <div class="card-header white-text primary-color">
            Recent comments and replies
          </div>
          <div class="card-body">
            <table class="table no-header mt-1">
              <tbody>
                <tr>
                  <td>John Doe</td>
                  <td>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit...
                  </td>
                  <td class="hour">
                    <small
                      ><span class="grey-text float-right"
                        ><i class="far fa-clock" aria-hidden="true"></i> 12
                        min</span
                      ></small
                    >
                  </td>
                </tr>
                <tr>
                  <td>Merry Joe</td>
                  <td>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit...
                  </td>
                  <td class="hour">
                    <small
                      ><span class="grey-text float-right"
                        ><i class="far fa-clock" aria-hidden="true"></i> 12
                        min</span
                      ></small
                    >
                  </td>
                </tr>
                <tr>
                  <td>Jessie Doe</td>
                  <td>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit...
                  </td>
                  <td class="hour">
                    <small
                      ><span class="grey-text float-right"
                        ><i class="far fa-clock" aria-hidden="true"></i> 12
                        min</span
                      ></small
                    >
                  </td>
                </tr>
              </tbody>
            </table>

            <mdb-btn
              dark-waves
              flat
              rounded
              class="grey lighten-3 float-right font-weight-bold dark-grey-text"
              >View full report</mdb-btn
            >
          </div>
        </mdb-card>
        <!--/.Panel-->

        <!-- Panel -->

        <div class="card mb-4">
          <div class="card-header white-text primary-color">
            Issues
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th class="font-weight-bold dark-grey-text">Status</th>
                    <th class="font-weight-bold dark-grey-text">Title</th>
                    <th class="font-weight-bold dark-grey-text">User</th>
                    <th class="font-weight-bold dark-grey-text">Date</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td><span class="badge green">Open</span></td>
                    <td>Lorem ipsum dolor</td>
                    <td>John Doe</td>
                    <td class="hour">
                      <small
                        ><span class="grey-text"
                          ><i class="far fa-clock" aria-hidden="true"></i> 12
                          min</span
                        ></small
                      >
                    </td>
                  </tr>
                  <tr>
                    <td><span class="badge green">Open</span></td>
                    <td>Lorem ipsum dolor</td>
                    <td>John Doe</td>
                    <td class="hour">
                      <small
                        ><span class="grey-text"
                          ><i class="far fa-clock" aria-hidden="true"></i> 12
                          min</span
                        ></small
                      >
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <span class="badge warning-color">In progress</span>
                    </td>
                    <td>Lorem ipsum dolor</td>
                    <td>John Doe</td>
                    <td class="hour">
                      <small
                        ><span class="grey-text"
                          ><i class="far fa-clock" aria-hidden="true"></i> 12
                          min</span
                        ></small
                      >
                    </td>
                  </tr>
                  <tr>
                    <td><span class="badge red">Closed</span></td>
                    <td>Lorem ipsum dolor</td>
                    <td>John Doe</td>
                    <td class="hour">
                      <small
                        ><span class="grey-text"
                          ><i class="far fa-clock" aria-hidden="true"></i> 12
                          min</span
                        ></small
                      >
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <!-- /.Panel -->
      </mdb-col>

      <!-- /.First column -->

      <div class="col-lg-6 col-md-12">
        <!--Panel-->
        <div class="card mb-4">
          <div class="card-header white-text primary-color">
            Users activity
          </div>
          <div class="card-body">
            <div class="row mb-1">
              <div class="col-4">
                <small class="grey-text">Pages/Visits</small>
                <h4>139 419</h4>
              </div>
              <div class="col-4">
                <small class="grey-text">New visitors</small>
                <h4>51.94%</h4>
              </div>
              <div class="col-4">
                <small class="grey-text">Last week</small>
                <h4>51 932</h4>
              </div>
            </div>
            <div class="row mb-1">
              <div class="col-4">
                <small class="grey-text">Pages/Visits</small>
                <h4>139 419</h4>
              </div>
              <div class="col-4">
                <small class="grey-text">New visitors</small>
                <h4>51.94%</h4>
              </div>
              <div class="col-4">
                <small>Last week</small>
                <h4>51 932</h4>
              </div>
            </div>

            <div class="row mb-1">
              <div class="col-4">
                <small class="grey-text">Pages/Visits</small>
                <h4>139 419</h4>
              </div>
              <div class="col-4">
                <small class="grey-text">New visitors</small>
                <h4>51.94%</h4>
              </div>
              <div class="col-4">
                <small class="grey-text">Last week</small>
                <h4>51 932</h4>
              </div>
            </div>

            <mdb-btn
              dark-waves
              flat
              rounded
              class="grey lighten-3 float-right font-weight-bold dark-grey-text"
              >View full report</mdb-btn
            >
          </div>
        </div>
        <!--/.Panel-->

        <!-- Panel -->
        <div class="card mb-4 text-center py-3 red accent-2 white-text">
          <i class="fas fa-bell fa-3x mb-3"></i>
          <h4 class="h4-responsive">28 important messages</h4>
        </div>
        <!-- /.Panel -->

        <!--Section: Intro-->
        <section class="mt-lg-5">
          <!--Grid row-->
          <div class="row">
            <!--Grid column-->
            <div class="col-md-6 mb-4">
              <!--Panel-->
              <div class="card">
                <div class="card-header white-text grey darken-1">
                  Orders
                </div>

                <h6 class="ml-4 pt-4 mt-1 dark-grey-text font-weight-bold">
                  <i
                    class="fas fa-long-arrow-up blue-text mr-3"
                    aria-hidden="true"
                  ></i>
                  2000
                </h6>
                <!--/.Card Data-->

                <!--Card content-->
                <div class="card-body">
                  <div class="progress">
                    <div
                      class="progress-bar bg-primary"
                      role="progressbar"
                      style="width: 45%"
                      aria-valuenow="25"
                      aria-valuemin="0"
                      aria-valuemax="100"
                    ></div>
                  </div>
                  <!--Text-->
                  <p class="font-small grey-text">
                    Better than last week (25%)
                  </p>
                </div>
                <!--/.Card content-->
              </div>
              <!--/.Panel-->
            </div>
            <!--Grid column-->

            <!--Grid column-->
            <div class=" col-md-6 mb-4">
              <!--Panel-->
              <div class="card">
                <div class="card-header white-text warning-color">
                  Monthly sales
                </div>

                <h6 class="ml-4 pt-4 mt-1 dark-grey-text font-weight-bold">
                  <i
                    class="fas fa-long-arrow-up blue-text mr-3"
                    aria-hidden="true"
                  ></i>
                  $ 2000
                </h6>
                <!--/.Card Data-->

                <!--Card content-->
                <div class="card-body">
                  <div class="progress">
                    <div
                      class="progress-bar bg-primary"
                      role="progressbar"
                      style="width: 65%"
                      aria-valuenow="65"
                      aria-valuemin="0"
                      aria-valuemax="100"
                    ></div>
                  </div>
                  <!--Text-->
                  <p class="font-small grey-text">
                    Better than last week (25%)
                  </p>
                </div>
                <!--/.Card content-->
              </div>
              <!--/.Panel-->
            </div>
            <!--Grid column-->
          </div>
          <!--Grid row-->
        </section>
        <!-- /.Second column -->
      </div>
      <!-- /.Second row -->
    </mdb-row>
  </mdb-container>
</template>

<script>
import {
  mdbContainer,
  mdbRow,
  mdbCol,
  mdbCard,
  mdbCardBody,
  mdbBtn
} from "mdbvue";

export default {
  name: "Dashboardv3",
  components: {
    mdbContainer,
    mdbRow,
    mdbCol,
    mdbCard,
    mdbCardBody,
    mdbBtn
  },
  data() {
    return {};
  }
};
</script>

<!-- Add 'scoped" attribute to limit CSS to this component only -->
<style scoped></style>
