<template>
  <mdb-container fluid>
    <!--Section: Button icon-->
    <section>
      <!--Grid row-->
      <mdb-row>
        <!--Grid column-->
        <mdb-col xl="3" md="6" class="mb-4">
          <!--Card-->
          <mdb-card>
            <!--Card Data-->
            <mdb-row class="mt-3">
              <mdb-col md="5" col="5" class=" text-left pl-4">
                <mdb-btn tag="a" floating size="lg" color="primary" class="ml-4"
                  ><mdb-icon icon="eye" aria-hidden="true"
                /></mdb-btn>
              </mdb-col>

              <mdb-col md="7" col="7" class=" text-right pr-5">
                <h5 class="ml-4 mt-4 mb-2 font-weight-bold">4,567</h5>
                <p class="font-small grey-text">Unique Visitors</p>
              </mdb-col>
            </mdb-row>
            <!--/.Card Data-->

            <!--Card content-->
            <mdb-row class="my-3">
              <mdb-col md="7" col="7" class=" text-left pl-4">
                <p
                  class="font-small dark-grey-text font-up ml-4 font-weight-bold"
                >
                  Last month
                </p>
              </mdb-col>

              <mdb-col md="5" col="5" class=" text-right pr-5">
                <p class="font-small grey-text">145,567</p>
              </mdb-col>
            </mdb-row>
            <!--/.Card content-->
          </mdb-card>
          <!--/.Card-->
        </mdb-col>
        <!--Grid column-->

        <!--Grid column-->
        <mdb-col xl="3" md="6" class="mb-4">
          <!--Card-->
          <mdb-card>
            <!--Card Data-->
            <mdb-row class="mt-3">
              <mdb-col md="5" col="5" class=" text-left pl-4">
                <mdb-btn tag="a" floating size="lg" color="warning" class="ml-4"
                  ><mdb-icon icon="user" aria-hidden="true"
                /></mdb-btn>
              </mdb-col>

              <mdb-col md="7" col="7" class=" text-right pr-5">
                <h5 class="ml-4 mt-4 mb-2 font-weight-bold">4,567</h5>
                <p class="font-small grey-text">New Users</p>
              </mdb-col>
            </mdb-row>
            <!--/.Card Data-->

            <!--Card content-->
            <mdb-row class="my-3">
              <mdb-col md="7" col="7" class=" text-left pl-4">
                <p
                  class="font-small dark-grey-text font-up ml-4 font-weight-bold"
                >
                  Last month
                </p>
              </mdb-col>

              <mdb-col md="5" col="5" class=" text-right pr-5">
                <p class="font-small grey-text">145,567</p>
              </mdb-col>
            </mdb-row>
            <!--/.Card content-->
          </mdb-card>
          <!--/.Card-->
        </mdb-col>
        <!--Grid column-->

        <!--Grid column-->
        <mdb-col xl="3" md="6" class="mb-4">
          <!--Card-->
          <mdb-card>
            <!--Card Data-->
            <mdb-row class="mt-3">
              <mdb-col md="5" col="5" class="text-left pl-4">
                <mdb-btn
                  tag="a"
                  floating
                  size="lg"
                  color="light-blue"
                  class="ml-4 lighten-1"
                  ><mdb-icon icon="dollar-sign" aria-hidden="true"
                /></mdb-btn>
              </mdb-col>

              <mdb-col md="7" col="7" class="text-right pr-5">
                <h5 class="ml-4 mt-4 mb-2 font-weight-bold">4,567</h5>
                <p class="font-small grey-text">Total Sales</p>
              </mdb-col>
            </mdb-row>
            <!--/.Card Data-->

            <!--Card content-->
            <mdb-row class="my-3">
              <mdb-col md="7" col="7" class="text-left pl-4">
                <p
                  class="font-small dark-grey-text font-up ml-4 font-weight-bold"
                >
                  Last month
                </p>
              </mdb-col>

              <mdb-col md="5" col="5" class="text-right pr-5">
                <p class="font-small grey-text">145,567</p>
              </mdb-col>
            </mdb-row>
            <!--/.Card content-->
          </mdb-card>
          <!--/.Card-->
        </mdb-col>
        <!--Grid column-->

        <!--Grid column-->
        <mdb-col xl="3" md="6" class="mb-4">
          <!--Card-->
          <mdb-card>
            <!--Card Data-->
            <mdb-row class="mt-3">
              <mdb-col md="5" col="5" class="text-left pl-4">
                <mdb-btn
                  tag="a"
                  floating
                  size="lg"
                  color="red"
                  class="ml-4 accent-2"
                  ><mdb-icon icon="database" aria-hidden="true"
                /></mdb-btn>
              </mdb-col>

              <mdb-col md="7" col="7" class="text-right pr-5">
                <h5 class="ml-4 mt-4 mb-2 font-weight-bold">4,567</h5>
                <p class="font-small grey-text">Order Amount</p>
              </mdb-col>
            </mdb-row>
            <!--/.Card Data-->

            <!--Card content-->
            <mdb-row class="my-3">
              <mdb-col md="7" col="7" class="text-left pl-4">
                <p
                  class="font-small dark-grey-text font-up ml-4 font-weight-bold"
                >
                  Last week
                </p>
              </mdb-col>

              <mdb-col md="5" col="5" class="text-right pr-5">
                <p class="font-small grey-text">145,567</p>
              </mdb-col>
            </mdb-row>
            <!--/.Card content-->
          </mdb-card>
          <!--/.Card-->
        </mdb-col>
        <!--Grid column-->
      </mdb-row>
      <!--Grid row-->
    </section>
    <!--/Section: Button icon-->

    <div style="height: 5px"></div>

    <!--Section: Analytical panel-->
    <section class="mb-5">
      <!--Card-->
      <mdb-card cascade narrow>
        <!--Section: Chart-->
        <section>
          <!--Grid row-->
          <mdb-row>
            <!--Grid column-->
            <mdb-col xl="5" md="12" class="mr-0">
              <!--Card image-->
              <div
                class="view view-cascade gradient-card-header light-blue lighten-1"
              >
                <h4 class="h4-responsive mb-0 font-weight-bold">Traffic</h4>
              </div>
              <!--/Card image-->

              <!--Card content-->
              <mdb-card-body cascade class="pb-0">
                <!--Panel data-->
                <mdb-row class="card-body pt-3">
                  <!--First column-->
                  <mdb-col md="12">
                    <!--Date select-->
                    <h4>
                      <span class="badge big-badge light-blue lighten-1"
                        >Data range</span
                      >
                    </h4>
                    <mdb-select
                      label="Choose time period"
                      :options="[
                        { value: 1, text: 'Today' },
                        { value: 2, text: 'Yesterday' },
                        { value: 3, text: 'Last 7 days' },
                        { value: 4, text: 'Last 30 days' },
                        { value: 5, text: 'Last week' },
                        { value: 6, text: 'Last month' }
                      ]"
                    />
                    <br />

                    <!--Date pickers-->
                    <h5>
                      <span class="badge big-badge light-blue lighten-1"
                        >Custom date</span
                      >
                    </h5>
                    <br />
                    <div class="mb-5">
                      <mdb-date-picker
                        class="mr-1"
                        label="From"
                        v-model="startTimeFrom"
                      ></mdb-date-picker>
                      <mdb-date-picker
                        v-model="startTimeTo"
                        label="To"
                      ></mdb-date-picker>
                    </div>
                  </mdb-col>
                  <!--/First column-->
                </mdb-row>
                <!--/Panel data-->
              </mdb-card-body>
              <!--/.Card content-->
            </mdb-col>
            <!--Grid column-->

            <!--Grid column-->
            <mdb-col xl="7" md="12" class="mb-4">
              <!--Card image-->
              <div class="view view-cascade gradient-card-header white">
                <!-- Chart -->
                <mdb-bar-chart
                  :data="barChartData"
                  :options="barChartOptions"
                  :height="300"
                ></mdb-bar-chart>
              </div>
              <!--/Card image-->
            </mdb-col>
            <!--Grid column-->
          </mdb-row>
          <!--Grid row-->
        </section>
        <!--Section: Chart-->
      </mdb-card>
      <!--/.Card-->
    </section>
    <!--Section: Analytical panel-->

    <!-- Section: data tables -->
    <section class="section">
      <mdb-row>
        <mdb-col md="12" lg="4">
          <mdb-card class="mb-4">
            <mdb-card-body>
              <div class="table-responsive">
                <table class="table large-header">
                  <thead>
                    <tr>
                      <th class="font-weight-bold dark-grey-text">
                        <strong>Keywords</strong>
                      </th>
                      <th class="font-weight-bold dark-grey-text">
                        <strong>Visits</strong>
                      </th>
                      <th class="font-weight-bold dark-grey-text">
                        <strong>Pages</strong>
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Design</td>
                      <td>15</td>
                      <td>307</td>
                    </tr>
                    <tr>
                      <td>Bootstrap</td>
                      <td>32</td>
                      <td>504</td>
                    </tr>
                    <tr>
                      <td>MDBootstrap</td>
                      <td>41</td>
                      <td>613</td>
                    </tr>
                    <tr>
                      <td>Frontend</td>
                      <td>14</td>
                      <td>208</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <mdb-btn
                dark-waves
                flat
                rounded
                class="grey lighten-3 float-right font-weight-bold dark-grey-text"
                >View full report</mdb-btn
              >
            </mdb-card-body>
          </mdb-card>
        </mdb-col>

        <mdb-col lg="8" md="12">
          <mdb-card class="mb-4">
            <mdb-card-body>
              <table class="table large-header">
                <thead>
                  <tr>
                    <th class="font-weight-bold dark-grey-text">
                      <strong>Browser</strong>
                    </th>
                    <th class="font-weight-bold dark-grey-text">
                      <strong>Visits</strong>
                    </th>
                    <th class="font-weight-bold dark-grey-text">
                      <strong>Pages</strong>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Google Chrome</td>
                    <td>15</td>
                    <td>307</td>
                  </tr>
                  <tr>
                    <td>Mozilla Firefox</td>
                    <td>32</td>
                    <td>504</td>
                  </tr>
                  <tr>
                    <td>Safari</td>
                    <td>41</td>
                    <td>613</td>
                  </tr>
                  <tr>
                    <td>Opera</td>
                    <td>14</td>
                    <td>208</td>
                  </tr>
                </tbody>
              </table>

              <mdb-btn
                dark-waves
                flat
                rounded
                class="grey lighten-3 float-right font-weight-bold dark-grey-text"
                >View full report</mdb-btn
              >
            </mdb-card-body>
          </mdb-card>
        </mdb-col>
      </mdb-row>
    </section>
    <!-- /.Section: data tables -->

    <!--Section: Cards color-->
    <section class="mt-2">
      <!--Grid row-->
      <mdb-row>
        <!--Grid column-->
        <mdb-col xl="3" md="6" class="mb-4">
          <!--Panel-->
          <mdb-card>
            <div class="card-header white-text primary-color">
              Orders
            </div>

            <h6 class="ml-4 mt-5 dark-grey-text font-weight-bold">
              <mdb-icon
                fas
                icon="long-arrow-alt-up blue-text mr-3"
                aria-hidden="true"
              ></mdb-icon>
              2000
            </h6>
            <!--/.Card Data-->

            <!--Card content-->
            <mdb-card-body>
              <div class="progress">
                <div
                  class="progress-bar grey darken-2"
                  role="progressbar"
                  style="width: 45%"
                  aria-valuenow="25"
                  aria-valuemin="0"
                  aria-valuemax="100"
                ></div>
              </div>
              <!--Text-->
              <p class="font-small grey-text">Better than last week (25%)</p>
            </mdb-card-body>
            <!--/.Card content-->
          </mdb-card>
          <!--/.Panel-->
        </mdb-col>
        <!--Grid column-->

        <!--Grid column-->
        <mdb-col xl="3" md="6" class="mb-4">
          <!--Panel-->
          <mdb-card>
            <div class="card-header white-text warning-color">
              Monthly sales
            </div>

            <h6 class="ml-4 mt-5 dark-grey-text font-weight-bold">
              <mdb-icon
                fas
                icon="long-arrow-alt-up blue-text mr-3"
                aria-hidden="true"
              />
              $ 2000
            </h6>
            <!--/.Card Data-->

            <!--Card content-->
            <mdb-card-body>
              <div class="progress">
                <div
                  class="progress-bar grey darken-2"
                  role="progressbar"
                  style="width: 65%"
                  aria-valuenow="65"
                  aria-valuemin="0"
                  aria-valuemax="100"
                ></div>
              </div>
              <!--Text-->
              <p class="font-small grey-text">Better than last week (25%)</p>
            </mdb-card-body>
            <!--/.Card content-->
          </mdb-card>
          <!--/.Panel-->
        </mdb-col>
        <!--Grid column-->

        <!--Grid column-->
        <mdb-col xl="3" md="6" class="mb-4">
          <!--Panel-->
          <mdb-card>
            <div class="card-header white-text light-blue lighten-1">
              Sales
            </div>

            <h6 class="ml-4 mt-5 dark-grey-text font-weight-bold">
              <mdb-icon
                fas
                icon="long-arrow-alt-down red-text mr-3"
                aria-hidden="true"
              />
              $ 2000
            </h6>
            <!--/.Card Data-->

            <!--Card content-->
            <mdb-card-body>
              <div class="progress">
                <div
                  class="progress-bar grey darken-2"
                  role="progressbar"
                  style="width: 25%"
                  aria-valuenow="25"
                  aria-valuemin="0"
                  aria-valuemax="100"
                ></div>
              </div>
              <!--Text-->
              <p class="font-small grey-text">Better than last week (25%)</p>
            </mdb-card-body>
            <!--/.Card content-->
          </mdb-card>
          <!--/.Panel-->
        </mdb-col>
        <!--Grid column-->

        <!--Grid column-->
        <mdb-col xl="3" md="6" class="mb-4">
          <!--Panel-->
          <mdb-card>
            <div class="card-header white-text red accent-2">
              Daily Sales
            </div>

            <h6 class="ml-4 mt-5 dark-grey-text font-weight-bold">
              <mdb-icon
                fas
                icon="long-arrow-alt-down red-text mr-3"
                aria-hidden="true"
              />
              $ 2000
            </h6>
            <!--/.Card Data-->

            <!--Card content-->
            <mdb-card-body>
              <div class="progress">
                <div
                  class="progress-bar grey darken-2"
                  role="progressbar"
                  style="width: 45%"
                  aria-valuenow="25"
                  aria-valuemin="0"
                  aria-valuemax="100"
                ></div>
              </div>
              <!--Text-->
              <p class="font-small grey-text">Better than last week (25%)</p>
            </mdb-card-body>
            <!--/.Card content-->
          </mdb-card>
          <!--/.Panel-->
        </mdb-col>
        <!--Grid column-->
      </mdb-row>
      <!--Grid row-->
    </section>
    <!--Section: Cards color-->

    <!--Section: Panels-->
    <section>
      <!--Grid row-->
      <mdb-row>
        <!--Grid column-->
        <mdb-col xl="5" md="12">
          <!--Card-->
          <mdb-card class="mb-4">
            <!--Card Data-->
            <mdb-row>
              <mdb-col md="12" class="text-center">
                <h5 class="mt-4 mb-4 font-weight-bold">Monthly Sales</h5>
              </mdb-col>
            </mdb-row>

            <!--Card content-->
            <mdb-card-body>
              <div class="progress mb-2 mt-1">
                <div
                  class="progress-bar warning-color"
                  role="progressbar"
                  style="width: 55%"
                  aria-valuenow="25"
                  aria-valuemin="0"
                  aria-valuemax="100"
                ></div>
              </div>
              <!--Text-->
              <p class="font-small grey-text mb-4">January</p>

              <div class="progress mb-2">
                <div
                  class="progress-bar red accent-2"
                  role="progressbar"
                  style="width: 35%"
                  aria-valuenow="25"
                  aria-valuemin="0"
                  aria-valuemax="100"
                ></div>
              </div>
              <!--Text-->
              <p class="font-small grey-text mb-4">Febuary</p>

              <div class="progress mb-2">
                <div
                  class="progress-bar primary-color"
                  role="progressbar"
                  style="width: 85%"
                  aria-valuenow="25"
                  aria-valuemin="0"
                  aria-valuemax="100"
                ></div>
              </div>
              <!--Text-->
              <p class="font-small grey-text mb-4">March</p>

              <div class="progress mb-2">
                <div
                  class="progress-bar light-blue lighten-1"
                  role="progressbar"
                  style="width: 70%"
                  aria-valuenow="25"
                  aria-valuemin="0"
                  aria-valuemax="100"
                ></div>
              </div>
              <!--Text-->
              <p class="font-small grey-text mb-2">April</p>
            </mdb-card-body>
            <!--/.Card content-->
          </mdb-card>
          <!--/.Card-->
        </mdb-col>
        <!--Grid column-->

        <!--Grid column-->
        <mdb-col xl="3" md="6" class="mb-2">
          <!--Card-->
          <mdb-card>
            <!--Card Data-->
            <mdb-row class="mt-4 mb-3">
              <mdb-col md="3" col="3" class="text-left pl-4">
                <!--Facebook-->
                <a class="p-2 m-2 fa-lg fb-ic"
                  ><i class="fab fa-facebook-f fa-2x blue-text"> </i
                ></a>
              </mdb-col>

              <mdb-col md="9" col="9" class="text-right pr-5">
                <p class="font-small grey-text mb-1">Facebook Users</p>
                <h5 class="ml-4 mb-2 font-weight-bold">4,567</h5>
              </mdb-col>
            </mdb-row>
            <!--/.Card Data-->
          </mdb-card>
          <!--/.Card-->

          <!--Card-->
          <mdb-card class="mt-4">
            <!--Card Data-->
            <mdb-row class="mt-4 mb-3">
              <mdb-col md="3" col="3" class="text-left pl-4">
                <!--Facebook-->
                <a class="p-2 m-2 fa-lg fb-ic"
                  ><i class="fab fa-google-plus-g fa-2x red-text"> </i
                ></a>
              </mdb-col>

              <mdb-col md="9" col="9" class="text-right pr-5">
                <p class="font-small grey-text mb-1">Google+ Users</p>
                <h5 class="ml-4 mb-2 font-weight-bold">2,669</h5>
              </mdb-col>
            </mdb-row>
            <!--/.Card Data-->
          </mdb-card>
          <!--/.Card-->

          <!--Card-->
          <mdb-card class="mt-4 mb-4">
            <!--Card Data-->
            <mdb-row class="mt-4 mb-3">
              <mdb-col md="3" col="3" class="text-left pl-4">
                <!--Facebook-->
                <a class="p-2 m-2 fa-lg fb-ic"
                  ><i class="fab fa-twitter fa-2x cyan-text"> </i
                ></a>
              </mdb-col>

              <mdb-col md="9" col="9" class="text-right pr-5">
                <p class="font-small grey-text mb-1">Twitter Users</p>
                <h5 class="ml-4 mb-2 font-weight-bold">3,562</h5>
              </mdb-col>
            </mdb-row>
            <!--/.Card Data-->
          </mdb-card>
          <!--/.Card-->
        </mdb-col>
        <!--Grid column-->

        <!--Grid column-->
        <mdb-col xl="4" md="6" class="mb-2">
          <!--Card-->
          <mdb-card class="mb-4">
            <mdb-card-body>
              <div class="table-responsive">
                <table class="table large-header mb-1">
                  <thead>
                    <tr>
                      <th class="font-weight-bold dark-grey-text">
                        <strong>Month</strong>
                      </th>
                      <th class="font-weight-bold dark-grey-text">
                        <strong>Visits</strong>
                      </th>
                      <th class="font-weight-bold dark-grey-text">
                        <strong>Sales</strong>
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>January</td>
                      <td>15</td>
                      <td>307</td>
                    </tr>
                    <tr>
                      <td>Febuary</td>
                      <td>32</td>
                      <td>504</td>
                    </tr>
                    <tr>
                      <td>March</td>
                      <td>41</td>
                      <td>613</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <mdb-btn
                dark-waves
                flat
                rounded
                class="grey lighten-3 float-right font-weight-bold dark-grey-text"
                >View full report</mdb-btn
              >
            </mdb-card-body>
          </mdb-card>
          <!--/.Card-->
        </mdb-col>
        <!--Grid column-->
      </mdb-row>
      <!--Grid row-->
    </section>
    <!--Section: Panels-->
  </mdb-container>
</template>

<script>
import {
  mdbContainer,
  mdbIcon,
  mdbSelect,
  mdbBtn,
  mdbDatePicker,
  mdbBarChart,
  mdbRow,
  mdbCol,
  mdbCard,
  mdbCardBody
} from "mdbvue";

export default {
  name: "Dashboardv6",
  components: {
    mdbContainer,
    mdbIcon,
    mdbSelect,
    mdbBtn,
    mdbDatePicker,
    mdbBarChart,
    mdbRow,
    mdbCol,
    mdbCard,
    mdbCardBody
  },
  data() {
    return {
      startTimeFrom: null,
      startTimeTo: null,
      barChartData: {
        labels: ["January", "February", "March", "April", "May"],
        datasets: [
          {
            label: "# of Votes",
            data: [12, 19, 3, 5, 2],
            backgroundColor: [
              "rgba(255, 99, 132, 0.2)",
              "rgba(54, 162, 235, 0.2)",
              "rgba(255, 206, 86, 0.2)",
              "rgba(75, 192, 192, 0.2)",
              "rgba(153, 102, 255, 0.2)"
            ],
            borderColor: [
              "rgba(255,99,132,1)",
              "rgba(54, 162, 235, 1)",
              "rgba(255, 206, 86, 1)",
              "rgba(75, 192, 192, 1)",
              "rgba(153, 102, 255, 1)"
            ],
            borderWidth: 1
          }
        ]
      },
      barChartOptions: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          xAxes: [
            {
              gridLines: {
                display: true,
                color: "rgba(0, 0, 0, 0.1)"
              },
              ticks: {
                fontColor: "black"
              }
            }
          ],
          yAxes: [
            {
              gridLines: {
                display: true,
                color: "rgba(0, 0, 0, 0.1)"
              },
              ticks: {
                beginAtZero: true,
                min: 0,
                fontColor: "black"
              }
            }
          ]
        },
        legend: {
          labels: {
            fontColor: "black"
          }
        }
      }
    };
  }
};
</script>

<!-- Add 'scoped" attribute to limit CSS to this component only -->
<style scoped></style>
