<template>

    <GmapMap
      :center="{lat:10, lng:10}"
      :zoom="7"
      style="width: 100%; height: 100vh"
    />

</template>

<script>

export default {
  name: 'Fullscreen',
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
