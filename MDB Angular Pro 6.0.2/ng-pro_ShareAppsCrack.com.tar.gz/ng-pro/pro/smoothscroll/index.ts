export * from './mdb-page-scroll.directive';
export * from './mdb-page-scroll.service';
export * from './mdb-page-scroll.config';
export * from './mdb-page-scroll.instance';
export * from './mdb-page-scroll-util.service';

export {MDBPageScrollModule} from './mdb-page-scroll.module';
