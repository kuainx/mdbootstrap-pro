export * from './char-counter.directive';
export * from './char-counter.module';
