import { IMyDate } from './date.interface';

export interface IMyDateRange {
  begin: IMyDate;
  end: IMyDate;
}
