import {Component} from '@angular/core';

@Component({
  selector: 'logo',
  template: `
  <ng-content></ng-content>
  `
})
export class LogoComponent {

}
